# DogeClickBot Bot
A bot to automate sending visiting ads, joining groups and messaging bots task.

# How to use?
1. Install **Python 3.7+**

2. Open command prompt (**Run as administrator**)

3. Install the requirements

   >`pip install -r requirements.txt`

4. Run in command prompt

   >`python start.py phone_number`

5. Wait
